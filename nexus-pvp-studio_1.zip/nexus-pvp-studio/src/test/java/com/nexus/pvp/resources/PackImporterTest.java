package com.nexus.pvp.resources;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PackImporterTest {
    @TempDir Path dir;

    private Path zip(String name, String... entries) throws IOException {
        Path z = dir.resolve(name);
        try (ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(z))) {
            for (String e : entries) {
                out.putNextEntry(new ZipEntry(e));
                out.write(1);
                out.closeEntry();
            }
        }
        return z;
    }

    @Test
    void importsValidPackAndRefusesOverwrite() throws Exception {
        Path z = zip("a.zip", "pack.mcmeta", "assets/x.png");
        Path dest = dir.resolve("packs");
        assertTrue(Files.exists(PackImporter.importZip(z, dest)));
        assertThrows(IOException.class, () -> PackImporter.importZip(z, dest));
    }

    @Test
    void rejectsPathTraversal() throws Exception {
        Path z = zip("b.zip", "pack.mcmeta", "../evil.txt");
        assertThrows(IOException.class, () -> PackImporter.validate(z));
    }

    @Test
    void rejectsMissingMcmeta() throws Exception {
        Path z = zip("c.zip", "folder/pack.mcmeta");
        assertThrows(IOException.class, () -> PackImporter.validate(z));
    }

    @Test
    void rejectsNonZip() throws Exception {
        Path z = dir.resolve("d.zip");
        Files.writeString(z, "not a zip");
        assertThrows(IOException.class, () -> PackImporter.validate(z));
    }
}
