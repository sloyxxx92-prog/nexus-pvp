package com.nexus.pvp.config;

import static org.junit.jupiter.api.Assertions.*;

import com.nexus.pvp.profiles.Profile;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ConfigManagerTest {
    @TempDir Path dir;

    @Test
    void defaultsHaveFourBuiltInProfiles() {
        NexusConfig c = NexusConfig.defaults();
        assertEquals(4, c.profiles.size());
        assertTrue(c.profiles.stream().allMatch(p -> p.builtIn));
        assertEquals(Profile.CRYSTAL_PVP, c.activeProfile);
    }

    @Test
    void missingFileGivesFreshDefaults() {
        NexusConfig c = ConfigManager.load(dir.resolve("none.json"));
        assertTrue(c.freshlyCreated);
    }

    @Test
    void saveAndLoadRoundTrip() throws Exception {
        NexusConfig c = NexusConfig.defaults();
        Profile n = c.addCopyOf(c.active(), "My Profile");
        n.crosshair.size = 9;
        c.activeProfile = n.id;
        Path f = dir.resolve("c.json");
        ConfigManager.save(f, c);
        NexusConfig back = ConfigManager.load(f);
        assertEquals(n.id, back.activeProfile);
        assertEquals(9, back.active().crosshair.size);
        assertFalse(back.active().builtIn);
    }

    @Test
    void corruptFileIsBackedUpAndDefaultsUsed() throws Exception {
        Path f = dir.resolve("c.json");
        Files.writeString(f, "{ this is not json");
        NexusConfig c = ConfigManager.load(f);
        assertEquals(4, c.profiles.size());
        assertFalse(Files.exists(f));
        try (var s = Files.list(dir)) {
            assertTrue(s.anyMatch(p -> p.getFileName().toString().contains(".broken-")));
        }
    }

    @Test
    void builtInsCannotBeDeletedButCustomCan() {
        NexusConfig c = NexusConfig.defaults();
        assertFalse(c.delete(Profile.SMP));
        Profile n = c.addNew("Temp");
        assertTrue(c.delete(n.id));
    }

    @Test
    void badValuesAreClamped() throws Exception {
        Path f = dir.resolve("c.json");
        Files.writeString(f, "{\"version\":1,\"activeProfile\":\"nope\",\"profiles\":[{\"id\":\"x\",\"name\":\"X\",\"crosshair\":{\"size\":9999,\"thickness\":-4}}]}");
        NexusConfig c = ConfigManager.load(f);
        assertEquals(Profile.CRYSTAL_PVP, c.activeProfile);
        assertEquals(20, c.find("x").crosshair.size);
        assertEquals(1, c.find("x").crosshair.thickness);
    }

    @Test
    void profileExportImportRoundTrip() throws Exception {
        Profile p = Profile.builtInDefault(Profile.BEDWARS);
        Path f = dir.resolve("p.json");
        ConfigManager.exportProfile(p, f);
        Profile back = ConfigManager.importProfile(f);
        assertEquals("BedWars", back.name);
        assertFalse(back.builtIn);
    }

    @Test
    void invalidProfileImportGivesReadableError() throws Exception {
        Path f = dir.resolve("bad.json");
        Files.writeString(f, "[1,2,3]");
        assertThrows(ConfigException.class, () -> ConfigManager.importProfile(f));
    }
}
