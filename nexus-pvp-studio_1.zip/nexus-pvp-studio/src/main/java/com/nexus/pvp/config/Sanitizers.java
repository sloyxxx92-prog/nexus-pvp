package com.nexus.pvp.config;

/** Public entry points to the package-private sanitizers of the settings classes. */
public final class Sanitizers {
    private Sanitizers() {}

    public static void crosshair(CrosshairSettings c) { c.sanitize(); }

    public static void hud(HudSettings h) { h.sanitize(); }
}
