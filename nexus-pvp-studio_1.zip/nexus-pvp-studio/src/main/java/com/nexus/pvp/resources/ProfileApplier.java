package com.nexus.pvp.resources;

import com.nexus.pvp.client.NexusClient;
import com.nexus.pvp.profiles.Profile;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;

/**
 * Applies a profile's resource-pack choices through Minecraft's own ResourcePackManager.
 * Resources are only reloaded when the enabled-pack list really changes, and a failed
 * reload restores the previous list.
 */
public final class ProfileApplier {
    private static boolean busy;
    private static boolean pending;

    private ProfileApplier() {}

    public static void applyActive(MinecraftClient client) {
        apply(client, NexusClient.active());
    }

    /** Must be called on the client thread. */
    public static void apply(MinecraftClient client, Profile p) {
        if (busy) {
            pending = true;
            return;
        }
        ResourcePackManager manager = client.getResourcePackManager();
        manager.scanPacks();

        List<String> desired = new ArrayList<>();
        for (String id : p.resourcePacks) {
            if (manager.getProfile(id) != null) desired.add(id);
        }
        String swords = NexusClient.SHORT_SWORDS_PACK.toString();
        desired.remove(swords);
        if (p.shortSwords && manager.getProfile(swords) != null) desired.add(swords); // top priority

        List<String> before = new ArrayList<>(manager.getEnabledIds());
        manager.setEnabledProfiles(desired);
        List<String> after = new ArrayList<>(manager.getEnabledIds());
        if (before.equals(after)) return; // nothing changed: no reload

        client.options.refreshResourcePacks(manager);
        reload(client, before, true);
    }

    private static void reload(MinecraftClient client, List<String> previous, boolean allowRollback) {
        busy = true;
        client.reloadResources().whenComplete((v, error) -> client.execute(() -> {
            busy = false;
            if (error != null && allowRollback) {
                NexusClient.LOG.error("Resource reload failed, restoring previous packs", error);
                ResourcePackManager m = client.getResourcePackManager();
                m.setEnabledProfiles(previous);
                client.options.refreshResourcePacks(m);
                reload(client, previous, false);
                return;
            }
            if (pending) {
                pending = false;
                applyActive(client);
            }
        }));
    }

    public static boolean isBusy() { return busy; }
}
