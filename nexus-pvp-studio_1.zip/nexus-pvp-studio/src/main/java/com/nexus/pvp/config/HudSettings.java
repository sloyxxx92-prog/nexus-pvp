package com.nexus.pvp.config;

/** HUD widget options. Positions are in scaled GUI pixels from the top-left corner. */
public final class HudSettings {
    public static final class Widget {
        public boolean enabled;
        public int x;
        public int y;

        public Widget() {}

        public Widget(boolean enabled, int x, int y) {
            this.enabled = enabled;
            this.x = x;
            this.y = y;
        }
    }

    public float scale = 1.0f;
    public Widget fps = new Widget(true, 4, 4);
    public Widget coords = new Widget(false, 4, 16);
    public Widget keystrokes = new Widget(false, 4, 30);

    void sanitize() {
        if (Float.isNaN(scale)) scale = 1.0f;
        scale = Math.max(0.5f, Math.min(2.0f, scale));
        if (fps == null) fps = new Widget(true, 4, 4);
        if (coords == null) coords = new Widget(false, 4, 16);
        if (keystrokes == null) keystrokes = new Widget(false, 4, 30);
        for (Widget w : new Widget[] {fps, coords, keystrokes}) {
            w.x = CrosshairSettings.clamp(w.x, 0, 1000);
            w.y = CrosshairSettings.clamp(w.y, 0, 1000);
        }
    }
}
