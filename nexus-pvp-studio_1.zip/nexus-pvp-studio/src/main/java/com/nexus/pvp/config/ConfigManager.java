package com.nexus.pvp.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.nexus.pvp.profiles.Profile;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Reads and writes the config and exported profile files safely. No Minecraft classes. */
public final class ConfigManager {
    private static final Logger LOG = Logger.getLogger("NEXUS PvP Studio");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final long MAX_FILE_BYTES = 512 * 1024;
    private static final int PROFILE_FILE_FORMAT = 1;

    private ConfigManager() {}

    /** Wrapper written to exported profile files. */
    static final class ProfileFile {
        int formatVersion = PROFILE_FILE_FORMAT;
        String app = "NEXUS PvP Studio";
        Profile profile;
    }

    /** Never throws: a missing, corrupted or too-new file is backed up and replaced by defaults. */
    public static NexusConfig load(Path file) {
        if (!Files.exists(file)) {
            NexusConfig c = NexusConfig.defaults();
            c.freshlyCreated = true;
            return c;
        }
        try {
            if (Files.size(file) > MAX_FILE_BYTES) throw new ConfigException("Config file is unreasonably large.");
            NexusConfig c;
            try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                c = GSON.fromJson(r, NexusConfig.class);
            }
            if (c == null) throw new ConfigException("Config file is empty.");
            if (c.version > NexusConfig.CURRENT_VERSION) {
                throw new ConfigException("Config was written by a newer version (" + c.version + ").");
            }
            // Older versions (< CURRENT_VERSION) would be migrated here; v1 is the first format.
            c.normalize();
            return c;
        } catch (ConfigException | IOException | JsonParseException | IllegalStateException e) {
            LOG.log(Level.WARNING, "Config could not be read, using defaults: " + e.getMessage(), e);
            backup(file);
            NexusConfig c = NexusConfig.defaults();
            c.freshlyCreated = true;
            return c;
        }
    }

    private static void backup(Path file) {
        try {
            Path b = file.resolveSibling(file.getFileName() + ".broken-" + System.currentTimeMillis());
            Files.move(file, b, StandardCopyOption.REPLACE_EXISTING);
            LOG.warning("Old config saved as " + b.getFileName());
        } catch (IOException e) {
            LOG.log(Level.WARNING, "Could not back up bad config", e);
        }
    }

    public static String toJson(NexusConfig cfg) {
        return GSON.toJson(cfg);
    }

    /** Writes via a temp file so a crash mid-write cannot corrupt the existing config. */
    public static void writeJson(Path file, String json) throws IOException {
        Files.createDirectories(file.toAbsolutePath().getParent());
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        Files.writeString(tmp, json, StandardCharsets.UTF_8);
        try {
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public static void save(Path file, NexusConfig cfg) throws IOException {
        writeJson(file, toJson(cfg));
    }

    public static void exportProfile(Profile p, Path file) throws IOException {
        ProfileFile f = new ProfileFile();
        f.profile = p.copy();
        f.profile.builtIn = false;
        writeJson(file, GSON.toJson(f));
    }

    /** Parses and validates an exported profile. The caller decides the final id. */
    public static Profile importProfile(Path file) throws ConfigException {
        try {
            if (!Files.isRegularFile(file)) throw new ConfigException("File not found: " + file.getFileName());
            if (Files.size(file) > MAX_FILE_BYTES) throw new ConfigException("File is too large to be a profile.");
            ProfileFile f;
            try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                f = GSON.fromJson(r, ProfileFile.class);
            }
            if (f == null || f.profile == null) throw new ConfigException("This is not a NEXUS profile file.");
            if (f.formatVersion > PROFILE_FILE_FORMAT) {
                throw new ConfigException("Profile was made with a newer version of NEXUS.");
            }
            f.profile.builtIn = false;
            f.profile.sanitize();
            return f.profile;
        } catch (JsonParseException | IllegalStateException e) {
            throw new ConfigException("Invalid profile file (bad JSON).", e);
        } catch (IOException e) {
            throw new ConfigException("Could not read file: " + e.getMessage(), e);
        }
    }
}
