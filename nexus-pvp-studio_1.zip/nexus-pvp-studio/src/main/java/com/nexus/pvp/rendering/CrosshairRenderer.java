package com.nexus.pvp.rendering;

import com.nexus.pvp.config.CrosshairSettings;
import net.minecraft.client.gui.DrawContext;

/** Draws the custom crosshair. Used by the in-game mixin and by the menu preview. */
public final class CrosshairRenderer {
    private static final int OUTLINE = 0xFF000000;

    private CrosshairRenderer() {}

    public static void draw(DrawContext ctx, int cx, int cy, CrosshairSettings s) {
        int t = s.thickness;
        int lo = t / 2;            // pixels before the centre line
        int hi = t - lo;           // pixels after
        switch (s.shape) {
            case CROSS -> {
                int g = s.gap, len = s.size;
                if (s.outline) {
                    arms(ctx, cx, cy, lo + 1, hi + 1, g - 1, len + 2, OUTLINE);
                }
                arms(ctx, cx, cy, lo, hi, g, len, s.color);
            }
            case DOT -> {
                int r = Math.max(1, s.size / 2);
                if (s.outline) ctx.fill(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, OUTLINE);
                ctx.fill(cx - r, cy - r, cx + r, cy + r, s.color);
            }
            case SQUARE -> {
                int r = s.size + s.gap;
                if (s.outline) frame(ctx, cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, t + 2, OUTLINE);
                frame(ctx, cx - r, cy - r, cx + r, cy + r, t, s.color);
            }
        }
    }

    private static void arms(DrawContext c, int cx, int cy, int lo, int hi, int gap, int len, int color) {
        c.fill(cx - gap - len, cy - lo, cx - gap, cy + hi, color); // left
        c.fill(cx + gap, cy - lo, cx + gap + len, cy + hi, color); // right
        c.fill(cx - lo, cy - gap - len, cx + hi, cy - gap, color); // top
        c.fill(cx - lo, cy + gap, cx + hi, cy + gap + len, color); // bottom
    }

    private static void frame(DrawContext c, int x1, int y1, int x2, int y2, int t, int color) {
        c.fill(x1, y1, x2, y1 + t, color);
        c.fill(x1, y2 - t, x2, y2, color);
        c.fill(x1, y1 + t, x1 + t, y2 - t, color);
        c.fill(x2 - t, y1 + t, x2, y2 - t, color);
    }
}
