package com.nexus.pvp.resources;

import com.nexus.pvp.client.NexusClient;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProfile;

/** Display data for one installed pack. Built once per refresh, not every frame. */
public record PackRow(String id, String name, String description, boolean compatible) {

    /** Lists installed packs the user may toggle (excludes required packs and the bundled sword pack). */
    public static List<PackRow> list(MinecraftClient client) {
        ResourcePackManager m = client.getResourcePackManager();
        m.scanPacks();
        List<PackRow> rows = new ArrayList<>();
        String swords = NexusClient.SHORT_SWORDS_PACK.toString();
        for (ResourcePackProfile p : m.getProfiles()) {
            if (p.isRequired() || p.getId().equals(swords)) continue;
            rows.add(new PackRow(p.getId(), p.getDisplayName().getString(),
                p.getDescription().getString().replace('\n', ' '), p.getCompatibility().isCompatible()));
        }
        return rows;
    }
}
