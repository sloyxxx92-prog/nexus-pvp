package com.nexus.pvp.ui;

import com.nexus.pvp.client.NexusClient;
import com.nexus.pvp.config.ConfigException;
import com.nexus.pvp.config.ConfigManager;
import com.nexus.pvp.config.CrosshairSettings;
import com.nexus.pvp.config.HudSettings;
import com.nexus.pvp.config.NexusConfig;
import com.nexus.pvp.hud.HudRenderer;
import com.nexus.pvp.profiles.Profile;
import com.nexus.pvp.rendering.CrosshairRenderer;
import com.nexus.pvp.resources.PackImporter;
import com.nexus.pvp.resources.PackRow;
import com.nexus.pvp.resources.ProfileApplier;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.DoubleConsumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * The NEXUS PvP Studio menu. Immediate-mode UI: every frame the visible controls register
 * "hit areas"; clicks and drags are routed to them. Expensive data (pack list) is cached.
 */
public final class NexusScreen extends Screen {
    private enum Page {
        HOME("Home"), PROFILES("Profiles"), PACKS("Resource Packs"), ITEMS("Items & Swords"), ARMOR("Armor"),
        CRYSTAL("Crystal PvP"), CROSSHAIR("Crosshair"), HUD("HUD"), PARTICLES("Particles"), SETTINGS("Settings");
        final String label;
        Page(String l) { label = l; }
    }

    private enum Edit { NONE, SEARCH, RENAME }

    private record Hit(int x, int y, int w, int h, Runnable click, DoubleConsumer drag) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    // palette
    private static final int BG = 0xE60A0A10, SIDE = 0xFF101018, PANEL = 0xFF171722, CARD = 0xFF1F1F2E;
    private static final int HOVER = 0xFF2A2A3F, PURPLE = 0xFFA855F7, CYAN = 0xFF22D3EE;
    private static final int TEXT = 0xFFE5E7EB, MUTED = 0xFF8B8FA3, RED = 0xFFF87171, GREEN = 0xFF4ADE80;
    private static final int[] SWATCHES = {0xFF22D3EE, 0xFFA855F7, 0xFFFFFFFF, 0xFF4ADE80, 0xFFF87171, 0xFFFACC15};

    private final Screen parent;
    private Page page = Page.HOME;
    private final List<Hit> hits = new ArrayList<>();
    private Hit dragging;
    private int mouseX, mouseY;

    private Edit edit = Edit.NONE;
    private String input = "";
    private String status = "";
    private long statusUntil;
    private boolean dirty;
    private boolean confirmReset, confirmDelete;

    // pack list cache
    private List<PackRow> allPacks = new ArrayList<>();
    private List<PackRow> shownPacks = new ArrayList<>();
    private boolean packsDirty = true;
    private int sortMode; // 0 A-Z, 1 enabled first, 2 priority
    private int scroll;

    public NexusScreen(Screen parent) {
        super(Text.literal("NEXUS PvP Studio"));
        this.parent = parent;
    }

    // ---------------------------------------------------------------- layout
    private int px, py, pw, ph, sideW, prevW, cx, cy, cw, ch;

    @Override
    protected void init() {
        packsDirty = true;
    }

    private void layout() {
        pw = Math.min(width - 8, 720);
        ph = Math.min(height - 8, 400);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        sideW = pw < 480 ? 86 : 112;
        prevW = pw >= 600 ? 150 : 0;
        cx = px + sideW + 8;
        cy = py + 8;
        cw = pw - sideW - prevW - (prevW > 0 ? 24 : 16);
        ch = ph - 16;
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        mouseX = mx;
        mouseY = my;
        hits.clear();
        layout();
        c.fill(0, 0, width, height, BG);
        round(c, px, py, pw, ph, PANEL);
        round(c, px, py, sideW, ph, SIDE);

        drawSidebar(c);
        switch (page) {
            case HOME -> pageHome(c);
            case PROFILES -> pageProfiles(c);
            case PACKS -> pagePacks(c);
            case ITEMS -> pageItems(c);
            case CROSSHAIR -> pageCrosshair(c);
            case HUD -> pageHud(c);
            case SETTINGS -> pageSettings(c);
            case ARMOR -> pagePlanned(c, "Armor & cosmetics", "Custom armor trims and colors need a verified rendering path for 1.21.4 before they are offered. Use the Resource Packs page to apply armor packs today.");
            case CRYSTAL -> pagePlanned(c, "Crystal PvP visuals", "End-crystal model/texture options are not implemented yet. Any resource pack that restyles crystals works through the Resource Packs page and per-profile pack lists.");
            case PARTICLES -> pagePlanned(c, "Particles", "Particle toggles are not implemented yet, so no fake switches are shown.");
        }
        if (prevW > 0) drawPreview(c);
        if (System.currentTimeMillis() < statusUntil) {
            text(c, status, px + sideW + 8, py + ph - 12, status.startsWith("!") ? RED : GREEN, cw + prevW);
        }
    }

    private void drawSidebar(DrawContext c) {
        text(c, "NEXUS", px + 10, py + 10, PURPLE, sideW);
        text(c, "PvP Studio", px + 10, py + 21, CYAN, sideW);
        int y = py + 38;
        int rowH = Math.min(24, (ph - 60) / Page.values().length);
        for (Page p : Page.values()) {
            boolean sel = p == page;
            boolean hov = inRect(px + 4, y, sideW - 8, rowH - 2);
            if (sel) round(c, px + 4, y, sideW - 8, rowH - 2, CARD);
            else if (hov) round(c, px + 4, y, sideW - 8, rowH - 2, HOVER);
            if (sel) c.fill(px + 4, y + 3, px + 6, y + rowH - 5, PURPLE);
            text(c, p.label, px + 11, y + (rowH - 10) / 2, sel ? TEXT : MUTED, sideW - 16);
            final Page target = p;
            hit(px + 4, y, sideW - 8, rowH - 2, () -> switchPage(target));
            y += rowH;
        }
    }

    private void switchPage(Page p) {
        page = p;
        edit = Edit.NONE;
        confirmReset = false;
        confirmDelete = false;
        scroll = 0;
        if (p == Page.PACKS) packsDirty = true;
    }

    // ---------------------------------------------------------------- pages
    private void title(DrawContext c, String t, String sub) {
        c.drawText(textRenderer, t, cx, cy, TEXT, true);
        text(c, sub, cx, cy + 12, MUTED, cw);
    }

    private void pageHome(DrawContext c) {
        Profile p = NexusClient.active();
        title(c, "Welcome to NEXUS", "One-click PvP profiles. Active: " + p.name);
        int y = cy + 32;
        round(c, cx, y, cw, 44, CARD);
        text(c, "Active profile", cx + 8, y + 6, MUTED, cw);
        c.drawText(textRenderer, p.name, cx + 8, y + 20, CYAN, true);
        text(c, enabledPacks(p) + " packs | " + (p.shortSwords ? "short swords | " : "") + (p.lowFire ? "low fire" : ""), cx + 8, y + 32, MUTED, cw - 16);
        y += 54;
        text(c, "Quick switch", cx, y, MUTED, cw);
        y += 12;
        int bw = (cw - 6) / 2;
        int i = 0;
        for (Profile q : NexusClient.config().profiles) {
            if (i >= 8) break;
            int bx = cx + (i % 2) * (bw + 6), by = y + (i / 2) * 22;
            button(c, bx, by, bw, 18, q.name, q.id.equals(p.id), () -> activate(q));
            i++;
        }
        y += ((Math.min(i, 8) + 1) / 2) * 22 + 6;
        toggleRow(c, cx, y, cw, "Short swords", p.shortSwords, () -> { p.shortSwords = !p.shortSwords; changed(true); });
        toggleRow(c, cx, y + 20, cw, "Low fire", p.lowFire, () -> { p.lowFire = !p.lowFire; changed(false); });
        toggleRow(c, cx, y + 40, cw, "Custom crosshair", p.crosshair.enabled, () -> { p.crosshair.enabled = !p.crosshair.enabled; changed(false); });
    }

    private void pageProfiles(DrawContext c) {
        NexusConfig cfg = NexusClient.config();
        Profile act = NexusClient.active();
        title(c, "Profiles", "Switching applies packs, HUD, crosshair and visuals. Drop a .json here to import.");
        int y = cy + 28;
        int rowsH = Math.max(40, ch - 28 - 56);
        int rowH = 20;
        int maxScroll = Math.max(0, cfg.profiles.size() * rowH - rowsH);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        c.enableScissor(cx, y, cx + cw, y + rowsH);
        int ry = y - scroll;
        for (Profile p : cfg.profiles) {
            if (ry + rowH > y && ry < y + rowsH) {
                boolean sel = p.id.equals(act.id);
                round(c, cx, ry, cw, rowH - 2, sel ? HOVER : (inRect(cx, ry, cw, rowH - 2) ? CARD : PANEL));
                if (sel) c.fill(cx, ry + 2, cx + 2, ry + rowH - 4, CYAN);
                text(c, p.name, cx + 8, ry + 5, TEXT, cw - 90);
                text(c, p.builtIn ? "built-in" : "custom", cx + cw - 52, ry + 5, MUTED, 50);
                if (sel) text(c, "ACTIVE", cx + cw - 100, ry + 5, GREEN, 46);
                if (ry >= y - 2 && ry + rowH <= y + rowsH + 2) hit(cx, ry, cw, rowH - 2, () -> activate(p));
            }
            ry += rowH;
        }
        c.disableScissor();
        scrollHit(y, rowsH);
        int by = cy + ch - 50;
        int bw = (cw - 12) / 3;
        button(c, cx, by, bw, 18, "Duplicate", false, () -> {
            Profile n = cfg.addCopyOf(act, shorten(act.name + " Copy"));
            if (n == null) { msg("!Profile limit reached."); return; }
            activate(n); msg("Created " + n.name);
        });
        button(c, cx + bw + 6, by, bw, 18, "New", false, () -> {
            Profile n = cfg.addNew("New Profile");
            if (n == null) { msg("!Profile limit reached."); return; }
            activate(n); msg("Created " + n.name);
        });
        button(c, cx + 2 * (bw + 6), by, bw, 18, "Export", false, () -> exportActive(act));
        by += 22;
        if (edit == Edit.RENAME) {
            inputBox(c, cx, by, cw - 60, "Type a name, Enter to save");
            button(c, cx + cw - 54, by, 54, 18, "Save", true, this::commitRename);
        } else {
            button(c, cx, by, bw, 18, "Rename", false, () -> {
                if (act.builtIn) { msg("!Built-in profiles cannot be renamed. Duplicate it first."); return; }
                edit = Edit.RENAME; input = act.name;
            });
            if (act.builtIn) {
                button(c, cx + bw + 6, by, bw, 18, "Reset profile", false, () -> { cfg.resetBuiltIn(act.id); changed(true); msg("Profile reset to factory settings."); });
                button(c, cx + 2 * (bw + 6), by, bw, 18, "Delete", false, () -> msg("!Built-in profiles cannot be deleted."));
            } else {
                button(c, cx + bw + 6, by, bw, 18, confirmDelete ? "Click to confirm" : "Delete", confirmDelete, () -> {
                    if (!confirmDelete) { confirmDelete = true; return; }
                    confirmDelete = false;
                    cfg.delete(act.id);
                    changed(true);
                    msg("Profile deleted.");
                });
            }
        }
    }

    private void pagePacks(DrawContext c) {
        Profile p = NexusClient.active();
        title(c, "Resource Packs", "Enabled packs apply to the active profile. Drop a .zip here to import.");
        if (packsDirty) refreshPacks();
        int y = cy + 28;
        inputBoxSearch(c, cx, y, cw - 98);
        String[] sorts = {"Sort: A-Z", "Sort: Enabled", "Sort: Priority"};
        button(c, cx + cw - 94, y, 94, 18, sorts[sortMode], false, () -> { sortMode = (sortMode + 1) % 3; packsDirty = true; });
        y += 22;
        text(c, enabledPacks(p) + " enabled | later in the order = higher priority", cx, y, MUTED, cw);
        y += 12;
        int listH = ch - (y - cy) - 24;
        int rowH = 28;
        int maxScroll = Math.max(0, shownPacks.size() * rowH - listH);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        c.enableScissor(cx, y, cx + cw, y + listH);
        int ry = y - scroll;
        for (PackRow r : shownPacks) {
            if (ry + rowH > y && ry < y + listH) {
                boolean on = p.resourcePacks.contains(r.id());
                round(c, cx, ry, cw, rowH - 2, on ? CARD : PANEL);
                if (on) c.fill(cx, ry + 2, cx + 2, ry + rowH - 4, PURPLE);
                text(c, r.name(), cx + 8, ry + 4, r.compatible() ? TEXT : RED, cw - 110);
                text(c, r.compatible() ? r.description() : "Incompatible with this Minecraft version", cx + 8, ry + 15, MUTED, cw - 110);
                boolean fully = ry >= y - 2 && ry + rowH <= y + listH + 2;
                int bx = cx + cw - 96;
                if (r.compatible() || on) {
                    miniButton(c, bx, ry + 5, 40, 16, on ? "ON" : "OFF", on, fully ? () -> togglePack(p, r.id()) : null);
                }
                if (on) {
                    miniButton(c, bx + 44, ry + 5, 22, 16, "Up", false, fully ? () -> movePack(p, r.id(), 1) : null);
                    miniButton(c, bx + 68, ry + 5, 24, 16, "Dn", false, fully ? () -> movePack(p, r.id(), -1) : null);
                }
            }
            ry += rowH;
        }
        c.disableScissor();
        if (shownPacks.isEmpty()) text(c, allPacks.isEmpty() ? "No extra packs found. Drop a .zip here to add one." : "No packs match your search.", cx + 4, y + 6, MUTED, cw);
        scrollHit(y, listH);
        button(c, cx, cy + ch - 20, 70, 16, "Refresh", false, () -> { packsDirty = true; msg("Pack list refreshed."); });
    }

    private void pageItems(DrawContext c) {
        Profile p = NexusClient.active();
        title(c, "Items & Swords", "Visual options saved per profile. Applied instantly.");
        int y = cy + 32;
        toggleRow(c, cx, y, cw, "Short swords (bundled pack)", p.shortSwords, () -> { p.shortSwords = !p.shortSwords; changed(true); });
        text(c, "Smaller, lower sword models for all 6 sword materials.", cx + 4, y + 20, MUTED, cw);
        y += 40;
        toggleRow(c, cx, y, cw, "Low fire", p.lowFire, () -> { p.lowFire = !p.lowFire; changed(false); });
        slider(c, cx, y + 22, cw, "Fire drop", p.lowFireDrop, 0.05f, 0.6f, "%.2f", v -> { p.lowFireDrop = v; dirty = true; });
        y += 52;
        text(c, "Live sword preview (real item models):", cx, y, MUTED, cw);
        y += 12;
        var swords = new net.minecraft.item.Item[] {Items.WOODEN_SWORD, Items.STONE_SWORD, Items.IRON_SWORD, Items.GOLDEN_SWORD, Items.DIAMOND_SWORD, Items.NETHERITE_SWORD};
        int cell = Math.max(24, Math.min(40, cw / 6));
        for (int i = 0; i < swords.length; i++) {
            round(c, cx + i * cell, y, cell - 2, cell - 2, CARD);
            float s = (cell - 2) / 16f;
            c.getMatrices().push();
            c.getMatrices().translate(cx + i * cell, y, 0f);
            c.getMatrices().scale(s, s, 1f);
            c.drawItem(new ItemStack(swords[i]), 0, 0);
            c.getMatrices().pop();
        }
    }

    private void pageCrosshair(DrawContext c) {
        Profile pr = NexusClient.active();
        CrosshairSettings s = pr.crosshair;
        title(c, "Crosshair", "Replaces the vanilla crosshair only while enabled.");
        int y = cy + 30;
        toggleRow(c, cx, y, cw, "Custom crosshair", s.enabled, () -> { s.enabled = !s.enabled; changed(false); });
        y += 22;
        button(c, cx, y, cw, 16, "Shape: " + s.shape.name(), false, () -> {
            CrosshairSettings.Shape[] v = CrosshairSettings.Shape.values();
            s.shape = v[(s.shape.ordinal() + 1) % v.length]; changed(false);
        });
        y += 20;
        slider(c, cx, y, cw, "Size", s.size, 1, 20, "%.0f", v -> { s.size = Math.round(v); dirty = true; });
        slider(c, cx, y + 20, cw, "Thickness", s.thickness, 1, 6, "%.0f", v -> { s.thickness = Math.round(v); dirty = true; });
        slider(c, cx, y + 40, cw, "Gap", s.gap, 0, 12, "%.0f", v -> { s.gap = Math.round(v); dirty = true; });
        y += 62;
        toggleRow(c, cx, y, cw, "Outline", s.outline, () -> { s.outline = !s.outline; changed(false); });
        y += 22;
        for (int i = 0; i < SWATCHES.length; i++) {
            int col = SWATCHES[i], sx = cx + i * 22;
            c.fill(sx, y, sx + 18, y + 14, col == s.color ? TEXT : 0xFF000000);
            c.fill(sx + 1, y + 1, sx + 17, y + 13, col);
            hit(sx, y, 18, 14, () -> { s.color = col; changed(false); });
        }
        y += 22;
        int bh = Math.max(40, cy + ch - y - 4), bw = Math.min(cw, 140);
        c.fill(cx, y, cx + bw, y + bh, 0xFF2B3A2B);
        c.fill(cx + 1, y + 1, cx + bw - 1, y + bh - 1, 0xFF3C4F3C);
        CrosshairRenderer.draw(c, cx + bw / 2, y + bh / 2, s);
        text(c, "Preview", cx + 4, y + 3, TEXT, bw);
    }

    private void pageHud(DrawContext c) {
        HudSettings h = NexusClient.active().hud;
        title(c, "HUD", "Each widget is independent. Positions are in GUI pixels.");
        int y = cy + 30;
        slider(c, cx, y, cw, "HUD scale", h.scale, 0.5f, 2.0f, "%.2f", v -> { h.scale = Math.round(v * 20f) / 20f; dirty = true; });
        y += 24;
        y = hudRow(c, y, "FPS counter", h.fps);
        y = hudRow(c, y, "Coordinates", h.coords);
        y = hudRow(c, y, "Keystrokes", h.keystrokes);
        int bh = Math.max(30, cy + ch - y - 4);
        c.enableScissor(cx, y, cx + cw, y + bh);
        c.fill(cx, y, cx + cw, y + bh, 0xFF1B2733);
        HudRenderer.draw(c, MinecraftClient.getInstance(), h, cx, y);
        c.disableScissor();
    }

    private int hudRow(DrawContext c, int y, String label, HudSettings.Widget w) {
        toggleRow(c, cx, y, cw - 120, label, w.enabled, () -> { w.enabled = !w.enabled; changed(false); });
        int bx = cx + cw - 116;
        text(c, "X " + w.x, bx, y + 5, MUTED, 30);
        miniButton(c, bx + 32, y + 2, 14, 14, "-", false, () -> { w.x = Math.max(0, w.x - 4); changed(false); });
        miniButton(c, bx + 48, y + 2, 14, 14, "+", false, () -> { w.x = Math.min(1000, w.x + 4); changed(false); });
        text(c, "Y " + w.y, bx + 64, y + 5, MUTED, 30);
        miniButton(c, bx + 90, y + 2, 12, 14, "-", false, () -> { w.y = Math.max(0, w.y - 4); changed(false); });
        miniButton(c, bx + 104, y + 2, 12, 14, "+", false, () -> { w.y = Math.min(1000, w.y + 4); changed(false); });
        return y + 20;
    }

    private void pageSettings(DrawContext c) {
        title(c, "Settings", "Configuration and maintenance.");
        int y = cy + 32;
        text(c, "Config: " + (NexusClient.configFile() == null ? "-" : NexusClient.configFile().toString()), cx, y, MUTED, cw);
        y += 16;
        button(c, cx, y, cw, 18, "Reload config from disk", false, () -> {
            NexusClient.replaceConfig(ConfigManager.load(NexusClient.configFile()));
            ProfileApplier.applyActive(MinecraftClient.getInstance());
            packsDirty = true;
            msg("Config reloaded.");
        });
        y += 24;
        button(c, cx, y, cw, 18, confirmReset ? "Click again to RESET EVERYTHING" : "Reset all settings to defaults", confirmReset, () -> {
            if (!confirmReset) { confirmReset = true; return; }
            confirmReset = false;
            NexusClient.replaceConfig(NexusConfig.defaults());
            changed(true);
            msg("All settings reset (resource packs left as they are).");
        });
        y += 30;
        text(c, "NEXUS PvP Studio 1.0.0 - MIT license. Visual customization only:", cx, y, MUTED, cw);
        text(c, "no packets, no combat changes, no anti-cheat bypasses.", cx, y + 11, MUTED, cw);
        text(c, "Shortcuts: Right Shift/Esc close | Up/Down change page | Ctrl+F search packs", cx, y + 27, MUTED, cw);
    }

    private void pagePlanned(DrawContext c, String name, String why) {
        title(c, name, "Not implemented yet");
        round(c, cx, cy + 32, cw, 70, CARD);
        wrap(c, why, cx + 8, cy + 40, cw - 16, MUTED);
    }

    private void drawPreview(DrawContext c) {
        int x = px + pw - prevW - 8, y = cy, w = prevW;
        round(c, x, y, w, ch, CARD);
        Profile p = NexusClient.active();
        text(c, "PREVIEW", x + 8, y + 8, MUTED, w);
        c.drawText(textRenderer, p.name, x + 8, y + 20, CYAN, true);
        float s = 3f;
        c.getMatrices().push();
        c.getMatrices().translate(x + w / 2f - 24, y + 36, 0f);
        c.getMatrices().scale(s, s, 1f);
        c.drawItem(new ItemStack(Items.DIAMOND_SWORD), 0, 0);
        c.getMatrices().pop();
        int ty = y + 90;
        ty = flag(c, x + 8, ty, "Short swords", p.shortSwords);
        ty = flag(c, x + 8, ty, "Low fire", p.lowFire);
        ty = flag(c, x + 8, ty, "Crosshair", p.crosshair.enabled);
        ty = flag(c, x + 8, ty, "FPS counter", p.hud.fps.enabled);
        ty = flag(c, x + 8, ty, "Coordinates", p.hud.coords.enabled);
        flag(c, x + 8, ty, "Keystrokes", p.hud.keystrokes.enabled);
        if (p.crosshair.enabled) CrosshairRenderer.draw(c, x + w - 24, y + ch - 24, p.crosshair);
    }

    private int flag(DrawContext c, int x, int y, String label, boolean on) {
        c.fill(x, y + 2, x + 5, y + 7, on ? GREEN : 0xFF444455);
        text(c, label, x + 9, y, on ? TEXT : MUTED, prevW - 24);
        return y + 12;
    }

    // ---------------------------------------------------------------- actions
    private void activate(Profile p) {
        NexusClient.config().activeProfile = p.id;
        confirmDelete = false;
        changed(true);
        msg("Profile: " + p.name);
    }

    /** @param reapply true when resource packs may need to change */
    private void changed(boolean reapply) {
        dirty = true;
        if (reapply) {
            ProfileApplier.applyActive(MinecraftClient.getInstance());
            packsDirty = true;
        }
    }

    private void togglePack(Profile p, String id) {
        if (!p.resourcePacks.remove(id)) p.resourcePacks.add(id);
        changed(true);
    }

    private void movePack(Profile p, String id, int dir) {
        int i = p.resourcePacks.indexOf(id), j = i + dir;
        if (i < 0 || j < 0 || j >= p.resourcePacks.size()) return;
        java.util.Collections.swap(p.resourcePacks, i, j);
        changed(true);
    }

    private void refreshPacks() {
        packsDirty = false;
        Profile p = NexusClient.active();
        allPacks = PackRow.list(MinecraftClient.getInstance());
        String q = edit == Edit.SEARCH ? input.toLowerCase(Locale.ROOT) : searchText.toLowerCase(Locale.ROOT);
        List<PackRow> rows = new ArrayList<>();
        for (PackRow r : allPacks) {
            if (q.isEmpty() || r.name().toLowerCase(Locale.ROOT).contains(q) || r.description().toLowerCase(Locale.ROOT).contains(q)) rows.add(r);
        }
        Comparator<PackRow> byName = Comparator.comparing(r -> r.name().toLowerCase(Locale.ROOT));
        if (sortMode == 0) rows.sort(byName);
        else if (sortMode == 1) rows.sort(Comparator.<PackRow>comparingInt(r -> p.resourcePacks.contains(r.id()) ? 0 : 1).thenComparing(byName));
        else rows.sort(Comparator.<PackRow>comparingInt(r -> {
            int i = p.resourcePacks.indexOf(r.id());
            return i < 0 ? Integer.MAX_VALUE : -i;
        }).thenComparing(byName));
        shownPacks = rows;
    }

    private String searchText = "";

    private void commitRename() {
        Profile p = NexusClient.active();
        String n = input.strip();
        edit = Edit.NONE;
        if (n.isEmpty() || p.builtIn) return;
        p.name = shorten(n);
        changed(false);
        msg("Renamed.");
    }

    private void exportActive(Profile p) {
        Path out = NexusClient.configDir().resolve("exports").resolve(p.id + ".json");
        CompletableFuture.runAsync(() -> {
            try {
                ConfigManager.exportProfile(p, out);
                postMsg("Exported to " + out);
            } catch (IOException e) {
                NexusClient.LOG.error("Export failed", e);
                postMsg("!Export failed: " + e.getMessage());
            }
        });
    }

    @Override
    public void onFilesDropped(List<Path> paths) {
        for (Path path : paths) {
            String n = path.getFileName().toString().toLowerCase(Locale.ROOT);
            if (n.endsWith(".json")) importProfile(path);
            else if (n.endsWith(".zip")) importPack(path);
            else msg("!Unsupported file: " + path.getFileName());
        }
    }

    private void importProfile(Path path) {
        try {
            Profile in = ConfigManager.importProfile(path); // small file, safe on the client thread
            Profile added = NexusClient.config().addCopyOf(in, in.name);
            if (added == null) { msg("!Profile limit reached."); return; }
            added.resourcePacks = new ArrayList<>(in.resourcePacks);
            activate(added);
        } catch (ConfigException e) {
            msg("!" + e.getMessage());
        }
    }

    private void importPack(Path zip) {
        Path dir = MinecraftClient.getInstance().getResourcePackDir();
        CompletableFuture.runAsync(() -> {
            try {
                Path target = PackImporter.importZip(zip, dir);
                MinecraftClient.getInstance().execute(() -> { packsDirty = true; msg("Imported " + target.getFileName()); });
            } catch (IOException e) {
                postMsg("!Import failed: " + e.getMessage());
            }
        });
    }

    private void msg(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 5000;
    }

    private void postMsg(String s) {
        MinecraftClient.getInstance().execute(() -> msg(s));
    }

    // ---------------------------------------------------------------- widgets
    private boolean inRect(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void hit(int x, int y, int w, int h, Runnable r) {
        if (r != null) hits.add(new Hit(x, y, w, h, r, null));
    }

    private void round(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + h, color);
        c.fill(x, y + 1, x + w, y + h - 1, color);
    }

    private void text(DrawContext c, String s, int x, int y, int color, int maxW) {
        c.drawText(textRenderer, textRenderer.trimToWidth(s, Math.max(10, maxW)), x, y, color, false);
    }

    private void wrap(DrawContext c, String s, int x, int y, int w, int color) {
        for (var line : textRenderer.wrapLines(Text.literal(s), w)) {
            c.drawText(textRenderer, line, x, y, color, false);
            y += 10;
        }
    }

    private String shorten(String s) {
        return s.length() > 32 ? s.substring(0, 32) : s;
    }

    private int enabledPacks(Profile p) {
        return p.resourcePacks.size();
    }

    private void button(DrawContext c, int x, int y, int w, int h, String label, boolean accent, Runnable r) {
        boolean hov = inRect(x, y, w, h);
        round(c, x, y, w, h, accent ? PURPLE : (hov ? HOVER : CARD));
        int tw = textRenderer.getWidth(label);
        c.drawText(textRenderer, textRenderer.trimToWidth(label, w - 4), x + Math.max(2, (w - tw) / 2), y + (h - 8) / 2, TEXT, false);
        hit(x, y, w, h, r);
    }

    private void miniButton(DrawContext c, int x, int y, int w, int h, String label, boolean on, Runnable r) {
        boolean hov = inRect(x, y, w, h);
        round(c, x, y, w, h, on ? PURPLE : (hov ? HOVER : 0xFF2B2B40));
        c.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, TEXT, false);
        hit(x, y, w, h, r);
    }

    private void toggleRow(DrawContext c, int x, int y, int w, String label, boolean on, Runnable flip) {
        boolean hov = inRect(x, y, w, 18);
        if (hov) round(c, x, y, w, 18, CARD);
        text(c, label, x + 4, y + 5, TEXT, w - 44);
        round(c, x + w - 30, y + 3, 26, 12, on ? PURPLE : 0xFF3A3A4D);
        int kx = on ? x + w - 16 : x + w - 29;
        round(c, kx, y + 4, 10, 10, TEXT);
        hit(x, y, w, 18, flip);
    }

    private void slider(DrawContext c, int x, int y, int w, String label, float value, float min, float max, String fmt, java.util.function.Consumer<Float> set) {
        int tx = x + w / 2, tw = w / 2 - 40;
        text(c, label, x + 4, y + 5, TEXT, w / 2 - 8);
        float f = Math.max(0f, Math.min(1f, (value - min) / (max - min)));
        c.fill(tx, y + 8, tx + tw, y + 10, 0xFF3A3A4D);
        c.fill(tx, y + 8, tx + (int) (tw * f), y + 10, CYAN);
        round(c, tx + (int) (tw * f) - 3, y + 4, 6, 10, TEXT);
        text(c, String.format(Locale.ROOT, fmt, value), tx + tw + 6, y + 5, MUTED, 34);
        hits.add(new Hit(tx - 4, y, tw + 8, 18, () -> {}, mx -> {
            float nf = (float) Math.max(0, Math.min(1, (mx - tx) / (double) tw));
            set.accept(min + nf * (max - min));
        }));
    }

    private void inputBox(DrawContext c, int x, int y, int w, String hint) {
        round(c, x, y, w, 18, 0xFF0F0F18);
        c.fill(x, y + 17, x + w, y + 18, PURPLE);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = input.isEmpty() && !blink ? hint : input + (blink ? "_" : "");
        text(c, shown, x + 5, y + 5, input.isEmpty() ? MUTED : TEXT, w - 10);
    }

    private void inputBoxSearch(DrawContext c, int x, int y, int w) {
        boolean focus = edit == Edit.SEARCH;
        round(c, x, y, w, 18, 0xFF0F0F18);
        c.fill(x, y + 17, x + w, y + 18, focus ? PURPLE : 0xFF3A3A4D);
        String t = focus ? input : searchText;
        boolean blink = focus && (System.currentTimeMillis() / 500) % 2 == 0;
        text(c, t.isEmpty() && !focus ? "Search packs (Ctrl+F)" : t + (blink ? "_" : ""), x + 5, y + 5, t.isEmpty() ? MUTED : TEXT, w - 10);
        hit(x, y, w, 18, () -> { edit = Edit.SEARCH; input = searchText; });
    }

    private int scrollTop, scrollH;

    private void scrollHit(int top, int h) {
        scrollTop = top;
        scrollH = h;
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            if (edit == Edit.SEARCH) { searchText = input; edit = Edit.NONE; packsDirty = true; }
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (h.in(mx, my)) {
                    if (h.drag() != null) { dragging = h; h.drag().accept(mx); }
                    else h.click().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { dragging.drag().accept(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) { dragging = null; saveIfDirty(); }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (page == Page.PACKS || page == Page.PROFILES) {
            scroll = Math.max(0, scroll - (int) (vertical * 14));
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (edit != Edit.NONE) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { cancelEdit(); return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) {
                input = input.substring(0, input.length() - 1);
                if (edit == Edit.SEARCH) { searchText = input; packsDirty = true; }
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                if (edit == Edit.RENAME) commitRename();
                else { searchText = input; edit = Edit.NONE; packsDirty = true; }
                return true;
            }
            return true; // swallow other keys while typing
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        if (key == GLFW.GLFW_KEY_F && (mods & GLFW.GLFW_MOD_CONTROL) != 0) {
            switchPage(Page.PACKS);
            edit = Edit.SEARCH;
            input = searchText;
            return true;
        }
        Page[] ps = Page.values();
        if (key == GLFW.GLFW_KEY_DOWN) { switchPage(ps[(page.ordinal() + 1) % ps.length]); return true; }
        if (key == GLFW.GLFW_KEY_UP) { switchPage(ps[(page.ordinal() + ps.length - 1) % ps.length]); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void cancelEdit() {
        if (edit == Edit.SEARCH) searchText = input;
        edit = Edit.NONE;
        packsDirty = true;
    }

    @Override
    public boolean charTyped(char chr, int mods) {
        if (edit != Edit.NONE && chr >= 32 && chr != 127 && input.length() < 32) {
            input += chr;
            if (edit == Edit.SEARCH) { searchText = input; packsDirty = true; }
            return true;
        }
        return super.charTyped(chr, mods);
    }

    private void saveIfDirty() {
        if (dirty) {
            dirty = false;
            NexusClient.saveAsync();
        }
    }

    @Override
    public void removed() {
        saveIfDirty();
    }

    @Override
    public void close() {
        saveIfDirty();
        MinecraftClient.getInstance().setScreen(parent);
    }
}
