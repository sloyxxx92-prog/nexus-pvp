package com.nexus.pvp.profiles;

import com.nexus.pvp.config.CrosshairSettings;
import com.nexus.pvp.config.HudSettings;
import com.nexus.pvp.config.Sanitizers;
import java.util.ArrayList;
import java.util.List;

/** One PvP profile: every setting that is applied when the profile becomes active. */
public final class Profile {
    public static final String CRYSTAL_PVP = "crystal_pvp";
    public static final String BEDWARS = "bedwars";
    public static final String FPS_MODE = "fps_mode";
    public static final String SMP = "smp";
    public static final List<String> BUILT_IN_IDS = List.of(CRYSTAL_PVP, BEDWARS, FPS_MODE, SMP);

    public String id = "custom";
    public String name = "Custom";
    public boolean builtIn = false;

    public boolean shortSwords = false;
    public boolean lowFire = false;
    /** How far (in blocks) the first-person fire overlay is pushed down when lowFire is on. */
    public float lowFireDrop = 0.25f;

    /** Enabled user resource packs, ordered from lowest to highest priority. */
    public List<String> resourcePacks = new ArrayList<>();
    public CrosshairSettings crosshair = new CrosshairSettings();
    public HudSettings hud = new HudSettings();

    public void sanitize() {
        if (id == null || id.isBlank()) id = "custom";
        if (name == null || name.isBlank()) name = "Unnamed";
        name = name.strip();
        if (name.length() > 32) name = name.substring(0, 32);
        if (Float.isNaN(lowFireDrop)) lowFireDrop = 0.25f;
        lowFireDrop = Math.max(0.05f, Math.min(0.6f, lowFireDrop));
        if (resourcePacks == null) resourcePacks = new ArrayList<>();
        List<String> unique = new ArrayList<>();
        for (String s : resourcePacks) {
            if (s != null && !s.isBlank() && s.length() <= 256 && !unique.contains(s)) unique.add(s);
        }
        resourcePacks = unique;
        if (crosshair == null) crosshair = new CrosshairSettings();
        if (hud == null) hud = new HudSettings();
        Sanitizers.crosshair(crosshair);
        Sanitizers.hud(hud);
    }

    public Profile copy() {
        Profile p = new Profile();
        p.id = id;
        p.name = name;
        p.builtIn = builtIn;
        p.shortSwords = shortSwords;
        p.lowFire = lowFire;
        p.lowFireDrop = lowFireDrop;
        p.resourcePacks = new ArrayList<>(resourcePacks);
        CrosshairSettings c = crosshair, n = p.crosshair;
        n.enabled = c.enabled; n.shape = c.shape; n.size = c.size; n.thickness = c.thickness;
        n.gap = c.gap; n.color = c.color; n.outline = c.outline;
        HudSettings h = hud, m = p.hud;
        m.scale = h.scale;
        m.fps = new HudSettings.Widget(h.fps.enabled, h.fps.x, h.fps.y);
        m.coords = new HudSettings.Widget(h.coords.enabled, h.coords.x, h.coords.y);
        m.keystrokes = new HudSettings.Widget(h.keystrokes.enabled, h.keystrokes.x, h.keystrokes.y);
        return p;
    }

    /** Factory for the built-in profile with the given id, or null if it is not built in. */
    public static Profile builtInDefault(String id) {
        Profile p = new Profile();
        p.id = id;
        p.builtIn = true;
        switch (id) {
            case CRYSTAL_PVP -> {
                p.name = "Crystal PvP";
                p.shortSwords = true;
                p.lowFire = true;
                p.crosshair.enabled = true;
                p.crosshair.color = 0xFF22D3EE;
                p.hud.fps.enabled = true;
                p.hud.keystrokes.enabled = true;
                p.hud.keystrokes.y = 18;
            }
            case BEDWARS -> {
                p.name = "BedWars";
                p.lowFire = true;
                p.crosshair.enabled = true;
                p.crosshair.shape = CrosshairSettings.Shape.SQUARE;
                p.crosshair.size = 3;
                p.crosshair.color = 0xFFA855F7;
                p.hud.fps.enabled = true;
                p.hud.keystrokes.enabled = true;
                p.hud.keystrokes.y = 18;
            }
            case FPS_MODE -> {
                p.name = "FPS Mode";
                p.lowFire = true;
                p.hud.fps.enabled = true;
            }
            case SMP -> {
                p.name = "SMP";
                p.hud.fps.enabled = false;
                p.hud.coords.enabled = true;
                p.hud.coords.y = 4;
            }
            default -> {
                return null;
            }
        }
        p.sanitize();
        return p;
    }
}
