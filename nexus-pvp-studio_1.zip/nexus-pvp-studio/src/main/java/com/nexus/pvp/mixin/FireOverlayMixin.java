package com.nexus.pvp.mixin;

import com.nexus.pvp.client.NexusClient;
import com.nexus.pvp.profiles.Profile;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Pushes the first-person fire overlay down so it blocks less of the screen. */
@Mixin(InGameOverlayRenderer.class)
public abstract class FireOverlayMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"))
    private static void nexuspvp$lowFireStart(MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
        matrices.push(); // always popped at RETURN so other overlays are unaffected
        Profile p = NexusClient.active();
        if (p.lowFire) matrices.translate(0.0f, -p.lowFireDrop, 0.0f);
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"))
    private static void nexuspvp$lowFireEnd(MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
        matrices.pop();
    }
}
