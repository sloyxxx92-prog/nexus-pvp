package com.nexus.pvp.config;

/** Custom crosshair options. Plain data, no Minecraft classes, so it can be unit tested. */
public final class CrosshairSettings {
    public enum Shape { CROSS, DOT, SQUARE }

    public boolean enabled = false;
    public Shape shape = Shape.CROSS;
    public int size = 5;
    public int thickness = 1;
    public int gap = 2;
    public int color = 0xFF22D3EE; // ARGB
    public boolean outline = true;

    void sanitize() {
        if (shape == null) shape = Shape.CROSS;
        size = clamp(size, 1, 20);
        thickness = clamp(thickness, 1, 6);
        gap = clamp(gap, 0, 12);
        if ((color >>> 24) == 0) color |= 0xFF000000;
    }

    static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
