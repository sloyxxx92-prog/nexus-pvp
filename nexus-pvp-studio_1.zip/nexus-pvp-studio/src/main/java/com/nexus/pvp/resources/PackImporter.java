package com.nexus.pvp.resources;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

/** Validates a resource-pack ZIP and copies it into the resourcepacks folder. No Minecraft classes. */
public final class PackImporter {
    static final int MAX_ENTRIES = 100_000;
    static final long MAX_TOTAL_BYTES = 2L * 1024 * 1024 * 1024;

    private PackImporter() {}

    /** @throws IOException with a readable message if the archive is invalid or the target exists */
    public static Path importZip(Path source, Path packDir) throws IOException {
        String fileName = source.getFileName().toString();
        if (!fileName.toLowerCase().endsWith(".zip")) throw new IOException("Not a .zip file.");
        validate(source);
        Files.createDirectories(packDir);
        Path target = packDir.resolve(fileName).normalize();
        if (!packDir.normalize().equals(target.getParent())) throw new IOException("Unsafe file name.");
        if (Files.exists(target)) {
            throw new FileAlreadyExistsException("A pack named '" + fileName + "' already exists. Rename the file or remove the old pack first.");
        }
        Files.copy(source, target);
        return target;
    }

    public static void validate(Path zip) throws IOException {
        boolean hasMeta = false;
        long total = 0;
        int count = 0;
        try (ZipFile zf = new ZipFile(zip.toFile())) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (++count > MAX_ENTRIES) throw new IOException("Archive has too many files.");
                String n = e.getName();
                if (!isSafeName(n)) throw new IOException("Unsafe path in archive: " + n);
                if (e.getSize() > 0) total += e.getSize();
                if (total > MAX_TOTAL_BYTES) throw new IOException("Archive is too large when unpacked.");
                if (n.equals("pack.mcmeta")) hasMeta = true;
            }
        } catch (ZipException e) {
            throw new IOException("Not a valid zip archive.", e);
        }
        if (!hasMeta) {
            throw new IOException("No pack.mcmeta at the top level. The pack may be inside a folder in the zip - re-zip it so pack.mcmeta is at the root.");
        }
    }

    static boolean isSafeName(String n) {
        if (n.isEmpty() || n.startsWith("/") || n.indexOf('\\') >= 0 || n.indexOf(':') >= 0 || n.indexOf('\0') >= 0) return false;
        for (String part : n.split("/")) if (part.equals("..")) return false;
        return true;
    }
}
