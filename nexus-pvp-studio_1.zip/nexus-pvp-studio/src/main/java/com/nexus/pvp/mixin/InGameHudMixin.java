package com.nexus.pvp.mixin;

import com.nexus.pvp.client.NexusClient;
import com.nexus.pvp.config.CrosshairSettings;
import com.nexus.pvp.rendering.CrosshairRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replaces the vanilla crosshair with the custom one, only while it is enabled. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Shadow @Final private MinecraftClient client;

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void nexuspvp$customCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        CrosshairSettings s = NexusClient.active().crosshair;
        if (!s.enabled) return;            // vanilla crosshair untouched
        ci.cancel();                       // never draw both
        if (!client.options.getPerspective().isFirstPerson()) return;
        CrosshairRenderer.draw(context, context.getScaledWindowWidth() / 2, context.getScaledWindowHeight() / 2, s);
    }
}
