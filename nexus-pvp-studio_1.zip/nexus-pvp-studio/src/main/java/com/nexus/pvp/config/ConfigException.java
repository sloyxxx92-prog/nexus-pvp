package com.nexus.pvp.config;

/** Thrown with a user-readable message when a config or profile file cannot be used. */
public final class ConfigException extends Exception {
    public ConfigException(String message) { super(message); }

    public ConfigException(String message, Throwable cause) { super(message, cause); }
}
