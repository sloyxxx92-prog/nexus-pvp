package com.nexus.pvp.client;

import com.nexus.pvp.config.ConfigManager;
import com.nexus.pvp.config.NexusConfig;
import com.nexus.pvp.hud.HudRenderer;
import com.nexus.pvp.profiles.Profile;
import com.nexus.pvp.resources.ProfileApplier;
import com.nexus.pvp.ui.NexusScreen;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Client entrypoint: loads config, registers the key, HUD and the bundled resource pack. */
public final class NexusClient implements ClientModInitializer {
    public static final String MOD_ID = "nexuspvp";
    public static final Logger LOG = LoggerFactory.getLogger("NEXUS PvP Studio");
    /** Profile id of the bundled short-sword pack as seen by Minecraft's pack manager. */
    public static final Identifier SHORT_SWORDS_PACK = Identifier.of(MOD_ID, "short_swords");

    private static NexusConfig config = NexusConfig.defaults();
    private static Path configFile;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "NEXUS-IO");
        t.setDaemon(true);
        return t;
    });
    private static KeyBinding openMenuKey;

    public static NexusConfig config() { return config; }

    /** The active profile. Always non-null. */
    public static Profile active() { return config.active(); }

    public static Path configDir() { return FabricLoader.getInstance().getConfigDir().resolve("nexuspvp"); }

    public static Path configFile() { return configFile; }

    /** Serializes on the calling thread (cheap) and writes on a background thread. */
    public static void saveAsync() {
        final String json = ConfigManager.toJson(config);
        IO.execute(() -> {
            try {
                ConfigManager.writeJson(configFile, json);
            } catch (IOException e) {
                LOG.error("Could not save NEXUS config", e);
            }
        });
    }

    /** Replaces the whole config (used by reset and reload). */
    public static void replaceConfig(NexusConfig newConfig) { config = newConfig; }

    @Override
    public void onInitializeClient() {
        configFile = configDir().resolve("config.json");
        config = ConfigManager.load(configFile);

        FabricLoader.getInstance().getModContainer(MOD_ID).ifPresent(container ->
            ResourceManagerHelper.registerBuiltinResourcePack(SHORT_SWORDS_PACK, container,
                Text.literal("NEXUS Short Swords"), ResourcePackActivationType.NORMAL));

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.nexuspvp.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.nexuspvp"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new NexusScreen(null));
            }
        });

        HudRenderer.register();

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            if (config.freshlyCreated) {
                seedProfilesFromCurrentPacks(client);
                config.freshlyCreated = false;
                saveAsync();
            }
            ProfileApplier.applyActive(client);
        });
        LOG.info("NEXUS PvP Studio loaded; active profile: {}", config.active().name);
    }

    /** First launch: every profile starts with the packs the player already has enabled. */
    private static void seedProfilesFromCurrentPacks(MinecraftClient client) {
        ResourcePackManager m = client.getResourcePackManager();
        List<String> current = new ArrayList<>();
        for (ResourcePackProfile p : m.getEnabledProfiles()) {
            if (!p.isRequired() && !p.getId().equals(SHORT_SWORDS_PACK.toString())) current.add(p.getId());
        }
        for (Profile p : config.profiles) p.resourcePacks = new ArrayList<>(current);
    }
}
