package com.nexus.pvp.config;

import com.nexus.pvp.profiles.Profile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Root of the persistent configuration file. */
public final class NexusConfig {
    public static final int CURRENT_VERSION = 1;
    public static final int MAX_PROFILES = 64;

    public int version = CURRENT_VERSION;
    public String activeProfile = Profile.CRYSTAL_PVP;
    public List<Profile> profiles = new ArrayList<>();

    /** Not saved. True when no config existed and defaults were just created. */
    public transient boolean freshlyCreated;

    public static NexusConfig defaults() {
        NexusConfig c = new NexusConfig();
        c.normalize();
        return c;
    }

    /** Repairs anything wrong: nulls, duplicate ids, missing built-ins, invalid active profile. */
    public void normalize() {
        version = CURRENT_VERSION;
        if (profiles == null) profiles = new ArrayList<>();
        List<Profile> clean = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Profile p : profiles) {
            if (p == null) continue;
            p.sanitize();
            if (!seen.add(p.id)) continue;
            p.builtIn = Profile.BUILT_IN_IDS.contains(p.id);
            clean.add(p);
        }
        List<Profile> ordered = new ArrayList<>();
        for (String id : Profile.BUILT_IN_IDS) {
            Profile found = null;
            for (Profile p : clean) if (p.id.equals(id)) found = p;
            ordered.add(found != null ? found : Profile.builtInDefault(id));
        }
        for (Profile p : clean) if (!p.builtIn && ordered.size() < MAX_PROFILES) ordered.add(p);
        profiles = ordered;
        if (find(activeProfile) == null) activeProfile = Profile.CRYSTAL_PVP;
    }

    public Profile find(String id) {
        if (id == null) return null;
        for (Profile p : profiles) if (p.id.equals(id)) return p;
        return null;
    }

    public Profile active() {
        Profile p = find(activeProfile);
        return p != null ? p : profiles.get(0);
    }

    public String uniqueId(String base) {
        String slug = base.toLowerCase().replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
        if (slug.isEmpty()) slug = "profile";
        String id = slug;
        int n = 2;
        while (find(id) != null) id = slug + "_" + n++;
        return id;
    }

    /** Adds a copy of src as a new custom profile. Returns null when the profile limit is reached. */
    public Profile addCopyOf(Profile src, String newName) {
        if (profiles.size() >= MAX_PROFILES) return null;
        Profile p = src.copy();
        p.name = newName;
        p.builtIn = false;
        p.id = uniqueId(newName);
        p.sanitize();
        profiles.add(p);
        return p;
    }

    public Profile addNew(String name) {
        return addCopyOf(new Profile(), name);
    }

    /** Deletes a custom profile. Built-in profiles cannot be deleted. */
    public boolean delete(String id) {
        Profile p = find(id);
        if (p == null || p.builtIn) return false;
        profiles.remove(p);
        if (activeProfile.equals(id)) activeProfile = Profile.CRYSTAL_PVP;
        return true;
    }

    /** Resets one built-in profile to its factory settings (keeps its resource-pack list). */
    public boolean resetBuiltIn(String id) {
        Profile fresh = Profile.builtInDefault(id);
        if (fresh == null) return false;
        for (int i = 0; i < profiles.size(); i++) {
            if (profiles.get(i).id.equals(id)) {
                fresh.resourcePacks = new ArrayList<>(profiles.get(i).resourcePacks);
                profiles.set(i, fresh);
                return true;
            }
        }
        return false;
    }
}
