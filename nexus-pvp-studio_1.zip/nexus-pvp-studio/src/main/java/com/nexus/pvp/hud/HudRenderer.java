package com.nexus.pvp.hud;

import com.nexus.pvp.client.NexusClient;
import com.nexus.pvp.config.HudSettings;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;

/** Draws the FPS, coordinates and keystrokes widgets of the active profile. */
public final class HudRenderer {
    private static final int TEXT = 0xFFFFFFFF;
    private static final int BG = 0x90000000;
    private static final int PRESSED = 0xE0A855F7;
    private static final int IDLE = 0x90101018;

    private HudRenderer() {}

    public static void register() {
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            draw(ctx, mc, NexusClient.active().hud, 0, 0);
        });
    }

    /** @param ox,oy origin offset in GUI pixels (used by the menu preview) */
    public static void draw(DrawContext ctx, MinecraftClient mc, HudSettings h, int ox, int oy) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate(ox, oy, 0f);
        ctx.getMatrices().scale(h.scale, h.scale, 1f);
        if (h.fps.enabled) label(ctx, mc, h.fps.x, h.fps.y, mc.getCurrentFps() + " FPS");
        if (h.coords.enabled && mc.player != null) {
            label(ctx, mc, h.coords.x, h.coords.y,
                String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (h.keystrokes.enabled) keystrokes(ctx, mc, h.keystrokes.x, h.keystrokes.y);
        ctx.getMatrices().pop();
    }

    private static void label(DrawContext ctx, MinecraftClient mc, int x, int y, String s) {
        int w = mc.textRenderer.getWidth(s);
        ctx.fill(x - 2, y - 2, x + w + 2, y + 10, BG);
        ctx.drawText(mc.textRenderer, s, x, y, TEXT, false);
    }

    private static void keystrokes(DrawContext ctx, MinecraftClient mc, int x, int y) {
        GameOptions o = mc.options;
        key(ctx, mc, x + 20, y, 18, 18, "W", o.forwardKey.isPressed());
        key(ctx, mc, x, y + 20, 18, 18, "A", o.leftKey.isPressed());
        key(ctx, mc, x + 20, y + 20, 18, 18, "S", o.backKey.isPressed());
        key(ctx, mc, x + 40, y + 20, 18, 18, "D", o.rightKey.isPressed());
        key(ctx, mc, x, y + 40, 58, 10, "JUMP", o.jumpKey.isPressed());
    }

    private static void key(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String s, boolean down) {
        ctx.fill(x, y, x + w, y + h, down ? PRESSED : IDLE);
        int tx = x + (w - mc.textRenderer.getWidth(s)) / 2;
        int ty = y + (h - 8) / 2;
        ctx.drawText(mc.textRenderer, s, tx, ty, TEXT, false);
    }
}
