# NEXUS PvP Studio

Client-side Fabric mod for **Minecraft Java 1.21.4**. Press **Right Shift** in game to open the menu.

> **Honest status:** this source was written without internet access, so it has **not been compiled or run yet**.
> Version numbers and a few Minecraft API names (marked below) were written from knowledge of 1.21.4 and may need a
> one-line fix on first build. See "If the build fails".

## What works (implemented in code)
- Menu (Right Shift / Esc), sidebar, search, mouse + keyboard (Up/Down change page, Ctrl+F searches packs)
- Profiles: Crystal PvP, BedWars, FPS Mode, SMP; switch, duplicate, rename, new, delete (custom only), reset built-in, export/import JSON
- Resource packs: list, search, sort, enable/disable, priority Up/Dn, incompatible packs shown, automatic rollback if a reload fails, ZIP import by dragging a `.zip` onto the menu (validated, no overwrite, no path traversal)
- Short swords: bundled pack (smaller, lower sword models for all six materials) toggled per profile
- Low fire: first-person fire overlay pushed down (adjustable)
- HUD: FPS, XYZ, keystrokes (W A S D + jump), scale, X/Y position, each toggleable
- Crosshair: shape, size, thickness, gap, color, outline, preview; vanilla crosshair is only hidden while the custom one is on
- Versioned JSON config; corrupted files are backed up to `config.json.broken-<time>` and defaults are used

## Not implemented (no fake switches)
Armor/cosmetics, Crystal visuals, Particles pages are placeholders. No 3D player preview. No pack icons/thumbnails.
Short-sword pack reuses vanilla textures with new model transforms (original, but no new textures).

## Setup (Windows)
1. Install **JDK 21** (e.g. Eclipse Temurin 21). Check: `java -version`.
2. Install **IntelliJ IDEA Community** (easiest) and open this folder as a Gradle project, or use the command line below.
3. The Gradle wrapper jar is not included. Run once (needs Gradle 8.12 installed): `gradle wrapper --gradle-version 8.12`
   (or copy `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.jar` from the official `fabric-example-mod`).

## Commands
- Test the game: `gradlew.bat runClient`
- Build the mod: `gradlew.bat build`  -> JAR is `build\libs\nexus-pvp-studio-1.0.0.jar`
- Unit tests only: `gradlew.bat test`

## Install in normal Minecraft
1. Install Fabric Loader for 1.21.4 (fabricmc.net) and **Fabric API 0.119.3+1.21.4**.
2. Copy `nexus-pvp-studio-1.0.0.jar` (not the `-sources` one) into `%appdata%\.minecraft\mods`.
3. Start the Fabric 1.21.4 profile, press Right Shift in a world or on the title screen.

## Files
Config: `.minecraft\config\nexuspvp\config.json`. Exports: `...\config\nexuspvp\exports\`. Put packs in `.minecraft\resourcepacks` or drag ZIPs onto the menu.

## If the build fails
- "could not resolve" versions: pick current 1.21.4 values at fabricmc.net/develop and edit `gradle.properties`.
- Mixin errors mentioning `renderFireOverlay` or `renderCrosshair`: the method signature differs; check Yarn 1.21.4 and adjust `src/main/java/com/nexus/pvp/mixin/`.
- `refreshResourcePacks` / `getEnabledIds` not found: see `ProfileApplier.java`; these are the two pack-manager calls to verify.
- `HudRenderCallback` deprecation warnings are harmless.

Bundled assets are original. Minecraft textures are not redistributed. MIT license.
